<?php
//Descomenta la línea que se corresponde con tu proyecto de 
//trabajo y comenta la línea que carga "db_orig.php".
//return require( __DIR__.'/db_orig.php');
//return require( __DIR__.'/db_proyecto_A.php');
//return require( __DIR__.'/db_proyecto_B.php');
return require( __DIR__.'/db_proyecto_C.php');
//return require( __DIR__.'/db_proyecto_D.php');
?>
<pre>
Descomenta la línea que se corresponde con tu proyecto de trabajo en el archivo de configuración de la base de datos.
<?php echo __FILE__; throw new Exception(); ?>
</pre>
