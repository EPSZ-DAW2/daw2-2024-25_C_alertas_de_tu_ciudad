<meta charset="utf-8">
# Descripción del proyecto de trabajo
<hr/>
En esta carpeta se tienen los archivos con la descripción del proyecto de trabajo.<br/>
<br/>
*** Si no están es que debes descomprimir/copiar aquí el archivo o archivos con la descripcion del trabajo que debas realizar para tenerlo a mano, o quizá debáis realizar las especificaciones antes de poneros a desarrollar código en tu equipo de trabajo.<br/>
<br/>
&nbsp;&nbsp;&nbsp;Los archivos con la especificación básica del proyecto son los siguientes:<br/>
<div style="text-align:justify;margin:0.75rem 1rem 0.75rem 3rem">
  <table style="display:inline-block;margin:0mm;text-align:justify;padding:0.25rem 0.75rem 0.25rem 0.75rem;background-color:#cde">
  
    <tr><td>&dzigrarr; <strong>Proyecto.txt</strong></td><td> - Ideas iniciales del proyecto (.txt)</td></tr>
    <tr><td>&dzigrarr; <strong>Proyecto_1y2.html</strong></td><td> - Descripción de Requisitos Iniciales y de Información / Datos (.html)</td></tr>
    <tr><td>&dzigrarr; <strong>Proyecto_3.html</strong></td><td> - Analisis Inicial de Funciones y Tareas (.html)</td></tr>
    <tr><td colspan="2">&xmap; Diseño del Diccionario de Datos:</td></tr>
    <tr><td style="padding-left:1.75rem;">&dzigrarr; <strong>Proyecto_04a.mwb</strong></td><td> - Diseño Inicial de la Base Datos (.mwb) (opcional)</td></tr>
    <tr><td style="padding-left:1.75rem;">&dzigrarr; <strong>Proyecto_04b.pdf</strong></td><td> - Diagrama Inicial de la Base Datos (.pdf) (opcional)</td></tr>
    <tr><td style="padding-left:1.75rem;">&dzigrarr; <strong>Proyecto_04c.sql</strong></td><td> - Esquema Inicial de la Base Datos (.sql)</td></tr>
    <tr><td>&dzigrarr; <strong>Proyecto_5.html</strong></td><td> - Equipo/Grupo de Trabajo y Tareas asignadas (.html)</td></tr>
  </table>
</div>